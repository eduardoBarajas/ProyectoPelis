package com.CODEns.BackendAPI.DTOs;

import com.CODEns.BackendAPI.Entities.Tag;

public class TagDTO {
	private int IdTag;
	private String Title;
	private String Status;
	private String Message;

	public TagDTO(Tag tag, String Status, String Message) {
		this.IdTag = tag.getId();
		this.Title = tag.getTitle();
		this.Status = Status;
		this.Message = Message;
	}
	    
	public TagDTO(String Status, String Message) {
		this.Status = Status;
		this.Message = Message;
	}
	
	public TagDTO(Tag tag) {
		this.IdTag = tag.getId();
		this.Title = tag.getTitle();
	}

	public String getTitle() { return Title; }

	public int getId() { return IdTag; }
	
	public void setId(Integer id) { this.IdTag = id; }
	
	public void setTitle(String Title) { this.Title = Title; }

	public String getStatus() {
		return Status;
	}

	public void setStatus(String Status) {
		this.Status = Status;
	}

	public String getMessage() {
		return Message;
	}

	public void setMessage(String Message) {
		this.Message = Message;
	}
}
