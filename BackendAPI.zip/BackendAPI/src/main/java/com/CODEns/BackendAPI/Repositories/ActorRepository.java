package com.CODEns.BackendAPI.Repositories;

public interface ActorRepository {

}
