package com.CODEns.BackendAPI.Entities;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class MovieReviews {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int IdMovieReviews;
    private int IdReview;
    private int IdMovie;
    
	public MovieReviews(int IdMovieReviews, int IdReview, int IdMovie) {
		this.IdMovieReviews = IdMovieReviews;
		this.IdReview = IdReview;
		this.IdMovie = IdMovie;
	}
	public int getIdMovieReviews() {
		return IdMovieReviews;
	}
	public void setIdMovieReviews(int IdMovieReviews) {
		this.IdMovieReviews = IdMovieReviews;
	}
	public int getIdReview() {
		return IdReview;
	}
	public void setIdReview(int IdReview) {
		this.IdReview = IdReview;
	}
	public int getIdMovie() {
		return IdMovie;
	}
	public void setIdMovie(int IdMovie) {
		this.IdMovie = IdMovie;
	}
    
    
}
