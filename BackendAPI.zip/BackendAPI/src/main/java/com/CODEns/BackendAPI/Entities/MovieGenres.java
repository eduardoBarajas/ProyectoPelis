package com.CODEns.BackendAPI.Entities;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class MovieGenres {
    @Id
	@GeneratedValue(strategy = GenerationType.AUTO)
    private int IdGenres;
    private int IdGenre;
    private int IdMovie;

    public MovieGenres(int IdGenres, int IdGenre) {
        this.IdGenres = IdGenres;
        this.IdGenre = IdGenre;
    }

    public int getIdGenre() { return IdGenre; }

	public void setIdGenre(int IdGenre) {
		this.IdGenre = IdGenre;
    }
    
    public int getId() { return IdGenres; }

	public void setIdGenres(int IdGenres) {
		this.IdGenres = IdGenres;
	}

	public int getIdMovie() {
		return IdMovie;
	}

	public void setIdMovie(int IdMovie) {
		this.IdMovie = IdMovie;
	}
	
	
}
