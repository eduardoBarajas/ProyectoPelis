package com.CODEns.BackendAPI.Repositories;

public interface FavoriteMoviesRepository {

}
