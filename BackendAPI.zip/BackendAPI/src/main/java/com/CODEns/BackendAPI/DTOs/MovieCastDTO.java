package com.CODEns.BackendAPI.DTOs;

import com.CODEns.BackendAPI.Entities.MovieCast;

public class MovieCastDTO {

	private int IdCast;
    private int IdActor;
    private int IdMovie;
    private String Status;
    private String Message;

    public MovieCastDTO(MovieCast cast, String status, String message) {
        this.IdActor = cast.getIdActor();
        this.IdCast = cast.getId();
        this.IdMovie = cast.getIdMovie();
        this.Status = status;
        this.Message = message;
    }
    
    public MovieCastDTO(String status, String message) {
        this.Status = status;
        this.Message = message;
    }
    
    public MovieCastDTO(MovieCast cast) {
        this.IdActor = cast.getIdActor();
        this.IdCast = cast.getId();
        this.IdMovie = cast.getIdMovie();
    }

    public int getId() { return IdCast; }

	public void setIdCast(int IdCast) {
		this.IdCast = IdCast;
    }
    
    public int getIdActor() { return IdActor; }

	public void setIdActor(int IdActor) {
		this.IdActor = IdActor;
	}

	public int getIdMovie() {
		return IdMovie;
	}

	public void setIdMovie(int IdMovie) {
		this.IdMovie = IdMovie;
	}

	public String getStatus() {
		return Status;
	}

	public void setStatus(String status) {
		Status = status;
	}

	public String getMessage() {
		return Message;
	}

	public void setMessage(String message) {
		Message = message;
	}
	
}
