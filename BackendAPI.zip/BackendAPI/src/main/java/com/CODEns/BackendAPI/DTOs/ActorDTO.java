package com.CODEns.BackendAPI.DTOs;

import com.CODEns.BackendAPI.Entities.Actor;

public class ActorDTO {
	private int IdActor;
    private String Name;
    private String Status;
    private String Message;

    public ActorDTO(Actor actor, String status, String message) {
        this.Name = actor.getName();
        this.IdActor = actor.getId();
        this.Status = status;
        this.Message = message;
    }
    
    public ActorDTO(String status, String message) {
        this.Status = status;
        this.Message = message;
    }
    
    public ActorDTO(Actor actor) {
        this.Name = actor.getName();
        this.IdActor = actor.getId();
    }

    public String getName() { return Name; }

    public int getId() { return IdActor; }

	public void setIdActor(int IdActor) {
		this.IdActor = IdActor;
	}

	public void setName(String Name) {
		this.Name = Name;
	}

	public String getStatus() {
		return Status;
	}

	public void setStatus(String status) {
		Status = status;
	}

	public String getMessage() {
		return Message;
	}

	public void setMessage(String message) {
		Message = message;
	}
	
	
}
