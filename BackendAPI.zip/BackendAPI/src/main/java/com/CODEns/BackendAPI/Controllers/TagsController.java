package com.CODEns.BackendAPI.Controllers;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.Resource;
import org.springframework.hateoas.Resources;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.CODEns.BackendAPI.DTOs.TagDTO;
import com.CODEns.BackendAPI.Entities.Tag;
import com.CODEns.BackendAPI.Interfaces.ControllerInterface;
import com.CODEns.BackendAPI.Services.TagsService;
import com.CODEns.BackendAPI.Utils.GenericResourceAssembler;

@RestController
@RequestMapping(path="/tags")
public class TagsController implements ControllerInterface<TagDTO, Tag> {

	@Autowired
	private TagsService tags_service;
	
	@Autowired
	private GenericResourceAssembler<TagDTO> resource_assembler;
	
	@Override
	@RequestMapping(value="/", method=RequestMethod.POST, consumes = MediaType.APPLICATION_FORM_URLENCODED_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public Resource<TagDTO> add(@ModelAttribute Tag entity) {
		return resource_assembler.toResource(tags_service.save(entity));
	}

	@Override
	@RequestMapping(value="/", method=RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public Resources<Resource<TagDTO>> getAll() {
		// regresa a json todos los usuarios
    	List<Resource<TagDTO>> tags_dto = tags_service.findAll().stream()
    			.map(tag -> resource_assembler.toResource(tag)).collect(Collectors.toList());
    	return new Resources<>(tags_dto);
	}

	@Override
	@RequestMapping(value="/{id}", method=RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public Resource<TagDTO> getById(@PathVariable Integer id) {
		TagDTO tag_dto = tags_service.getById(id);
		return resource_assembler.toResource(tag_dto);
	}

	@Override
	@RequestMapping(value="/{id}", method=RequestMethod.DELETE, produces = MediaType.APPLICATION_JSON_VALUE)
	public Resource<TagDTO> deleteById(@PathVariable Integer id) {
		TagDTO tag = tags_service.deleteById(id);
		return resource_assembler.toResource(tag);
	}

	@Override
	@RequestMapping(value="/{id}", method=RequestMethod.PUT, consumes = MediaType.APPLICATION_FORM_URLENCODED_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public Resource<TagDTO> update(@ModelAttribute Tag entity, @PathVariable Integer id) {
		// se tuvo que dejar con la variable en el url debido a que ModelAttribute no mapeo el atributo id_usuario
		entity.setIdTag(id);
		TagDTO tag_dto = tags_service.update(entity);
		return resource_assembler.toResource(tag_dto);
	}

}
