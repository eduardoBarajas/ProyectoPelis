package com.CODEns.BackendAPI.DTOs;

import com.CODEns.BackendAPI.Entities.Links;

public class LinksDTO {

	private int IdLinkVideo;
    private String Link;
    private String Status;
    private String Message;

    public LinksDTO(Links links, String status, String message) {
        this.IdLinkVideo = links.getIdLinkVideo();
        this.Link = links.getLink();
        this.Status = status;
        this.Message = message;
    }
    
    public LinksDTO(String status, String message) {
        this.Status = status;
        this.Message = message;
    }
    
    public LinksDTO(Links links) {
        this.IdLinkVideo = links.getIdLinkVideo();
        this.Link = links.getLink();
    }

	public int getIdLinkVideo() {
		return IdLinkVideo;
	}

	public void setIdLinkVideo(int IdLinkVideo) {
		this.IdLinkVideo = IdLinkVideo;
	}

	public String getLink() {
		return Link;
	}

	public void setLink(String Link) {
		this.Link = Link;
	}

	public String getStatus() {
		return Status;
	}

	public void setStatus(String status) {
		Status = status;
	}

	public String getMessage() {
		return Message;
	}

	public void setMessage(String message) {
		Message = message;
	}
	
}
