package com.CODEns.BackendAPI.DTOs;

import java.util.LinkedList;
import java.util.List;

import com.CODEns.BackendAPI.Entities.Movie;

public class MovieDTO {
	private int IdMovie;
    private String Title;
    private String OriginalTitle;
    private String Synopsis;
    private int Lenght;
    private String PosterLink;
    private List<String> Tags = new LinkedList<>();
    private String Status;
    private String Message;

    public MovieDTO(Movie mv, String Status, String Message) {
    	this.IdMovie = mv.getIdMovie();
    	this.Lenght = mv.getLenght();
    	this.OriginalTitle = mv.getOriginalTitle();
    	this.PosterLink = mv.getPosterLink();
    	this.Synopsis = mv.getSynopsis();
    	this.Title = mv.getTitle();
    	this.Status = Status;
    	this.Message = Message;
    }
    
    public MovieDTO(String Status, String Message) {
    	this.Status = Status;
    	this.Message = Message;
    }
    
    public MovieDTO(Movie mv) {
    	this.IdMovie = mv.getIdMovie();
    	this.Lenght = mv.getLenght();
    	this.OriginalTitle = mv.getOriginalTitle();
    	this.PosterLink = mv.getPosterLink();
    	this.Synopsis = mv.getSynopsis();
    	this.Title = mv.getTitle();
    }

	public int getIdMovie() {
		return IdMovie;
	}

	public void setIdMovie(int IdMovie) {
		this.IdMovie = IdMovie;
	}

	public String getTitle() {
		return Title;
	}

	public void setTitle(String Title) {
		this.Title = Title;
	}

	public String getOriginalTitle() {
		return OriginalTitle;
	}

	public void setOriginalTitle(String OriginalTitle) {
		this.OriginalTitle = OriginalTitle;
	}

	public String getSynopsis() {
		return Synopsis;
	}

	public void setSynopsis(String Synopsis) {
		this.Synopsis = Synopsis;
	}

	public int getLenght() {
		return Lenght;
	}

	public void setLenght(int Lenght) {
		this.Lenght = Lenght;
	}

	public String getPosterLink() {
		return PosterLink;
	}

	public void setPosterLink(String PosterLink) {
		this.PosterLink = PosterLink;
	}

	public String getStatus() {
		return Status;
	}

	public void setStatus(String Status) {
		this.Status = Status;
	}

	public String getMessage() {
		return Message;
	}

	public void setMessage(String Message) {
		this.Message = Message;
	}

	public List<String> getTags() {
		return Tags;
	}

	public void setTags(List<String> Tags) {
		this.Tags = Tags;
	}
}
