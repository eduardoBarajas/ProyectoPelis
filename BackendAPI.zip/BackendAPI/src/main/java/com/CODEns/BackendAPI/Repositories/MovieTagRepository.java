package com.CODEns.BackendAPI.Repositories;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.CODEns.BackendAPI.Entities.MovieTags;

public interface MovieTagRepository extends CrudRepository<MovieTags, Integer>{

	List<MovieTags> findByIdMovie(Integer idMovie);
}
