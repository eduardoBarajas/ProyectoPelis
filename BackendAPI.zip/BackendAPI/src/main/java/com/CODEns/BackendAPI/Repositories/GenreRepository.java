package com.CODEns.BackendAPI.Repositories;

public interface GenreRepository {

}
