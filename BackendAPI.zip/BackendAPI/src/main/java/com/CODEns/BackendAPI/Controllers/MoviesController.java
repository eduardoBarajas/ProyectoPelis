package com.CODEns.BackendAPI.Controllers;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.Resource;
import org.springframework.hateoas.Resources;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.CODEns.BackendAPI.DTOs.MovieDTO;
import com.CODEns.BackendAPI.Entities.Movie;
import com.CODEns.BackendAPI.Interfaces.ControllerInterface;
import com.CODEns.BackendAPI.Services.MoviesService;
import com.CODEns.BackendAPI.Utils.GenericResourceAssembler;

@RestController
@RequestMapping(path="/movies")
public class MoviesController implements ControllerInterface<MovieDTO, Movie> {

	@Autowired
	private MoviesService movies_service;
	
	@Autowired
	private GenericResourceAssembler<MovieDTO> resource;
	
	@Override
	@RequestMapping(value = "/", method = RequestMethod.POST, consumes = MediaType.APPLICATION_FORM_URLENCODED_VALUE,  produces = MediaType.APPLICATION_JSON_VALUE)
	public Resource<MovieDTO> add(@ModelAttribute Movie entity) {
		return resource.toResource(movies_service.save(entity));
	}

	@Override
	@RequestMapping(value = "/", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public Resources<Resource<MovieDTO>> getAll() {
		List<Resource<MovieDTO>> movies = movies_service.findAll().stream()
				.map( movie -> resource.toResource(movie)).collect(Collectors.toList());
		return new Resources<>(movies);
	}

	@Override
	@RequestMapping(value = "/{id}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public Resource<MovieDTO> getById(@PathVariable Integer id) {
		return resource.toResource(movies_service.getById(id));
	}

	@Override
	@RequestMapping(value = "/{id}", method = RequestMethod.DELETE, produces = MediaType.APPLICATION_JSON_VALUE)
	public Resource<MovieDTO> deleteById(@PathVariable Integer id) {
		return resource.toResource(movies_service.deleteById(id));
	}

	@Override
	@RequestMapping(value = "/{id}", method = RequestMethod.PUT, consumes = MediaType.APPLICATION_FORM_URLENCODED_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public Resource<MovieDTO> update(@ModelAttribute Movie entity, @PathVariable Integer id) {
		entity.setIdMovie(id);
		return resource.toResource(movies_service.update(entity));
	}

}
