package com.CODEns.BackendAPI.Services;

import java.util.LinkedList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.CODEns.BackendAPI.DTOs.MovieDTO;
import com.CODEns.BackendAPI.Entities.Movie;
import com.CODEns.BackendAPI.Entities.MovieTags;
import com.CODEns.BackendAPI.Interfaces.ServiceInterface;
import com.CODEns.BackendAPI.Repositories.MovieRepository;
import com.CODEns.BackendAPI.Repositories.MovieTagRepository;
import com.CODEns.BackendAPI.Repositories.TagRepository;

@Service
public class MoviesService implements ServiceInterface<Movie, MovieDTO> {

	@Autowired
	private TagRepository tagRepository;
	
	@Autowired
	private MovieTagRepository movie_tagsRepository;
	
	@Autowired
	private MovieRepository movieRepository;
	
	@Override
	public MovieDTO save(Movie entity) {
		Movie new_movie = movieRepository.save(entity);
		MovieDTO movie_dto;
		if (new_movie.getIdMovie() > 0) {
			movie_dto = new MovieDTO(new_movie, "Success", "Se almaceno la pelicula con exito.");
		} else {
			movie_dto = new MovieDTO("Error", "No se pudo guardar la pelicula en la base de datos.");
		}
		return movie_dto;
	}

	@Override
	public List<MovieDTO> findAll() {
		List<MovieDTO> movies_dto = new LinkedList<>();
		for(Movie movie : movieRepository.findAll()) {
			movies_dto.add(new MovieDTO(movie));
		}
		return movies_dto;
	}

	@Override
	public MovieDTO getById(Integer id) {
		MovieDTO movie_dto = new MovieDTO("Error", "No se encontro la pelicula en la base de datos.");
		if (movieRepository.existsById(id)) {
			Movie movie = movieRepository.findById(id).get();
			movie_dto = new MovieDTO(movie, "Success", "Se obtuvo la pelicula con exito.");
			for(MovieTags movie_tag : movie_tagsRepository.findByIdMovie(movie.getIdMovie())) {
				movie_dto.getTags().add(tagRepository.findById(movie_tag.getIdTag()).get().getTitle());
			}
		}
		return movie_dto;
	}

	@Override
	public MovieDTO deleteById(Integer id) {
		MovieDTO movie_dto = new MovieDTO("Error", "No existe esa pelicula en la base de datos.");
		if (movieRepository.existsById(id)) {
			movieRepository.deleteById(id);
			movie_dto.setMessage("Se elimino la pelicula con exito.");
			movie_dto.setStatus("Success");
		}
		return movie_dto;
	}

	@Override
	public MovieDTO update(Movie entity) {
		MovieDTO movie_dto = new MovieDTO("Error", "No se encontro la pelicula en la base de datos.");
		if (movieRepository.existsById(entity.getIdMovie())) {
			movie_dto = new MovieDTO(movieRepository.save(entity), "Success", "Se actualizo la pelicula con exito.");
		}
		return movie_dto;
	}

}
