package com.CODEns.BackendAPI.Entities;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Tag {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
    private int IdTag;
    private String Title;

    public Tag(int id, String Title) {
        this.IdTag = id;
        this.Title = Title;
    }
    
    public Tag() {
    	
    }

    public String getTitle() { return Title; }

    public int getId() { return IdTag; }

	public void setIdTag(int IdTag) {
		this.IdTag = IdTag;
	}

	public void setTitle(String Title) {
		this.Title = Title;
	}
    
    
}