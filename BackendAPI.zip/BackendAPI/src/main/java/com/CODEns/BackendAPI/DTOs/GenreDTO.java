package com.CODEns.BackendAPI.DTOs;

import com.CODEns.BackendAPI.Entities.Genre;

public class GenreDTO {
	private int IdGenre;
    private String Title;
    private String Status;
    private String Message;

    public GenreDTO(Genre genre, String status, String message) {
        this.IdGenre = genre.getId();
        this.Title = genre.getTitle();
        this.Status = status;
        this.Message = message;
    }
    
    public GenreDTO(String status, String message) {
        this.Status = status;
        this.Message = message;
    }
    
    public GenreDTO(Genre genre) {
        this.IdGenre = genre.getId();
        this.Title = genre.getTitle();
    }

    public String getTitle() { return Title; }

    public int getId() { return IdGenre; }

	public void setIdGenre(int IdGenre) {
		this.IdGenre = IdGenre;
	}

	public void setTitle(String Title) {
		this.Title = Title;
	}

	public String getStatus() {
		return Status;
	}

	public void setStatus(String status) {
		Status = status;
	}

	public String getMessage() {
		return Message;
	}

	public void setMessage(String message) {
		Message = message;
	}
	
	
}
