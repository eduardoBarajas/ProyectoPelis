package com.CODEns.BackendAPI.Entities;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Review {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
    private int IdReview;
    private double Calification;
    private String Review;
    private int IdUser;

    public Review(int id, int IdUser, double cal, String rev) {
        IdReview = id;
        this.IdUser = IdUser;
        Calification = cal;
        Review = rev;
    }

	public int getId_Review() {
		return IdReview;
	}

	public void setId_Review(int IdReview) {
		this.IdReview = IdReview;
	}

	public double getCalification() {
		return Calification;
	}

	public void setCalification(double Calification) {
		this.Calification = Calification;
	}

	public String getReview() {
		return Review;
	}

	public void setReview(String Review) {
		this.Review = Review;
	}

	public int getIdUser() {
		return IdUser;
	}

	public void setIdUser(int IdUser) {
		this.IdUser = IdUser;
	}

}