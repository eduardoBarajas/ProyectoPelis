package com.CODEns.BackendAPI.Entities;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class MovieTags {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int IdMovieTags;
    private int IdTag;
    private int idMovie;
    
	public MovieTags(int IdMovieTags, int IdTag, int idmovie) {
		this.IdMovieTags = IdMovieTags;
		this.IdTag = IdTag;
		this.idMovie = idmovie;
	}
	
	public MovieTags() {
		
	}
	
	public int getIdMovieTags() {
		return IdMovieTags;
	}
	public void setIdMovieTags(int IdMovieTags) {
		this.IdMovieTags = IdMovieTags;
	}
	public int getIdTag() {
		return IdTag;
	}
	public void setIdTag(int IdTag) {
		this.IdTag = IdTag;
	}
	public int getIdMovie() {
		return idMovie;
	}
	public void setIdMovie(int IdMovie) {
		this.idMovie = IdMovie;
	}
    
    
}
