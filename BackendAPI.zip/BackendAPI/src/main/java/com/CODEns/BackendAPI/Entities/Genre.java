package com.CODEns.BackendAPI.Entities;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Genre {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
    private int IdGenre;
    private String Title;

    public Genre(int id, String Title) {
        this.IdGenre = id;
        this.Title = Title;
    }

    public String getTitle() { return Title; }

    public int getId() { return IdGenre; }

	public void setIdGenre(int IdGenre) {
		this.IdGenre = IdGenre;
	}

	public void setTitle(String Title) {
		this.Title = Title;
	}
    
}