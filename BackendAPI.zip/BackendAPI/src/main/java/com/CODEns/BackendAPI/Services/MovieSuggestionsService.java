package com.CODEns.BackendAPI.Services;

public class MovieSuggestionsService {

}
