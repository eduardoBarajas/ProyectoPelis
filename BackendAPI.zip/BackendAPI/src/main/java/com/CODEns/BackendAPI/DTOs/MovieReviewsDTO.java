package com.CODEns.BackendAPI.DTOs;

import com.CODEns.BackendAPI.Entities.MovieReviews;

public class MovieReviewsDTO {
	private int IdMovieReviews;
    private int IdReview;
    private int IdMovie;
    private String Status;
    private String Message;
    
	public MovieReviewsDTO(MovieReviews movieReviews, String status, String message) {
		this.IdMovieReviews = movieReviews.getIdMovieReviews();
		this.IdReview = movieReviews.getIdReview();
		this.IdMovie = movieReviews.getIdMovie();
		this.Message = message;
		this.Status = status;
	}
	
	public MovieReviewsDTO(String status, String message) {
		this.Message = message;
		this.Status = status;
	}
	
	public MovieReviewsDTO(MovieReviews movieReviews) {
		this.IdMovieReviews = movieReviews.getIdMovieReviews();
		this.IdReview = movieReviews.getIdReview();
		this.IdMovie = movieReviews.getIdMovie();
	}
	
	public int getIdMovieReviews() {
		return IdMovieReviews;
	}
	public void setIdMovieReviews(int IdMovieReviews) {
		this.IdMovieReviews = IdMovieReviews;
	}
	public int getIdReview() {
		return IdReview;
	}
	public void setIdReview(int IdReview) {
		this.IdReview = IdReview;
	}
	public int getIdMovie() {
		return IdMovie;
	}
	public void setIdMovie(int IdMovie) {
		this.IdMovie = IdMovie;
	}

	public String getStatus() {
		return Status;
	}

	public void setStatus(String status) {
		Status = status;
	}

	public String getMessage() {
		return Message;
	}

	public void setMessage(String message) {
		Message = message;
	}
	
}
