package com.CODEns.BackendAPI.Services;

import java.util.LinkedList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.CODEns.BackendAPI.DTOs.MovieTagDTO;
import com.CODEns.BackendAPI.Entities.MovieTags;
import com.CODEns.BackendAPI.Interfaces.ServiceInterface;
import com.CODEns.BackendAPI.Repositories.MovieTagRepository;

@Service
public class MovieTagsService implements ServiceInterface<MovieTags, MovieTagDTO>{

	@Autowired
	private MovieTagRepository movietagsRepository;
	
	@Override
	public MovieTagDTO save(MovieTags entity) {
		MovieTags new_tags = movietagsRepository.save(entity);
		MovieTagDTO tags_dto;
		if (new_tags.getIdMovieTags() > 0) {
			tags_dto = new MovieTagDTO(new_tags, "Success", "Se almaceno el tag con exito.");
		} else {
			tags_dto = new MovieTagDTO("Error", "No se pudo guardar el tag en la base de datos.");
		}
		return tags_dto;
	}

	@Override
	public List<MovieTagDTO> findAll() {
		List<MovieTagDTO> tags_dto = new LinkedList<>();
		for(MovieTags tag : movietagsRepository.findAll()) {
			tags_dto.add(new MovieTagDTO(tag));
		}
		return tags_dto;
	}

	@Override
	public MovieTagDTO getById(Integer id) {
		MovieTagDTO tag_dto = new MovieTagDTO("Error", "No se encontro el tag en la base de datos.");
		if (movietagsRepository.existsById(id)) {
			MovieTags tags = movietagsRepository.findById(id).get();
			tag_dto = new MovieTagDTO(tags, "Success", "Se obtuvo el tag con exito.");
		}
		return tag_dto;
	}

	@Override
	public MovieTagDTO deleteById(Integer id) {
		MovieTagDTO tag_dto = new MovieTagDTO("Error", "No existe ese tag en la base de datos.");
		if (movietagsRepository.existsById(id)) {
			movietagsRepository.deleteById(id);
			tag_dto.setMessage("Se elimino ese tag con exito.");
			tag_dto.setStatus("Success");
		}
		return tag_dto;
	}

	@Override
	public MovieTagDTO update(MovieTags entity) {
		MovieTagDTO tag_dto = new MovieTagDTO("Error", "No se encontro el tag en la base de datos.");
		if (movietagsRepository.existsById(entity.getIdMovieTags())) {
			tag_dto = new MovieTagDTO(movietagsRepository.save(entity), "Success", "Se actualizo el tag con exito.");
		}
		return tag_dto;
	}

}
