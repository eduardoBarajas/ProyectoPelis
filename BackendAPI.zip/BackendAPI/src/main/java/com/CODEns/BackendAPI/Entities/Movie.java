package com.CODEns.BackendAPI.Entities;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Movie {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
    private int IdMovie;
    private String Title;
    private String OriginalTitle;
    private String Synopsis;
    private int Lenght;
    private String PosterLink;

    public Movie() {
    	
    }
    
    public Movie(String Title) {
        this.Title = Title;
    }

	public int getIdMovie() {
		return IdMovie;
	}

	public void setIdMovie(int IdMovie) {
		this.IdMovie = IdMovie;
	}

	public String getTitle() {
		return Title;
	}

	public void setTitle(String Title) {
		this.Title = Title;
	}

	public String getOriginalTitle() {
		return OriginalTitle;
	}

	public void setOriginalTitle(String OriginalTitle) {
		this.OriginalTitle = OriginalTitle;
	}

	public String getSynopsis() {
		return Synopsis;
	}

	public void setSynopsis(String Synopsis) {
		this.Synopsis = Synopsis;
	}

	public int getLenght() {
		return Lenght;
	}

	public void setLenght(int Lenght) {
		this.Lenght = Lenght;
	}

	public String getPosterLink() {
		return PosterLink;
	}

	public void setPosterLink(String PosterLink) {
		this.PosterLink = PosterLink;
	}
    
}