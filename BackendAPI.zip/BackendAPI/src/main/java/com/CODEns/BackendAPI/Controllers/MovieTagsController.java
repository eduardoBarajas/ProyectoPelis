package com.CODEns.BackendAPI.Controllers;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.Resource;
import org.springframework.hateoas.Resources;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.CODEns.BackendAPI.DTOs.MovieTagDTO;
import com.CODEns.BackendAPI.Entities.MovieTags;
import com.CODEns.BackendAPI.Interfaces.ControllerInterface;
import com.CODEns.BackendAPI.Services.MovieTagsService;
import com.CODEns.BackendAPI.Utils.GenericResourceAssembler;

@RestController
@RequestMapping(path="/movie_tags")
public class MovieTagsController implements ControllerInterface<MovieTagDTO, MovieTags>{

	@Autowired
	private MovieTagsService tags_service;
	
	@Autowired
	private GenericResourceAssembler<MovieTagDTO> resource;
	
	@Override
	@RequestMapping(value = "/", method = RequestMethod.POST, consumes = MediaType.APPLICATION_FORM_URLENCODED_VALUE,  produces = MediaType.APPLICATION_JSON_VALUE)
	public Resource<MovieTagDTO> add(@ModelAttribute MovieTags entity) {
		return resource.toResource(tags_service.save(entity));
	}

	@Override
	@RequestMapping(value = "/", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public Resources<Resource<MovieTagDTO>> getAll() {
		List<Resource<MovieTagDTO>> movie_tags = tags_service.findAll().stream()
				.map( tag -> resource.toResource(tag)).collect(Collectors.toList());
		return new Resources<>(movie_tags);
	}

	@Override
	@RequestMapping(value = "/{id}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public Resource<MovieTagDTO> getById(@PathVariable Integer id) {
		return resource.toResource(tags_service.getById(id));
	}

	@Override
	@RequestMapping(value = "/{id}", method = RequestMethod.DELETE, produces = MediaType.APPLICATION_JSON_VALUE)
	public Resource<MovieTagDTO> deleteById(@PathVariable Integer id) {
		return resource.toResource(tags_service.deleteById(id));
	}

	@Override
	@RequestMapping(value = "/{id}", method = RequestMethod.PUT, consumes = MediaType.APPLICATION_FORM_URLENCODED_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public Resource<MovieTagDTO> update(@ModelAttribute MovieTags entity, @PathVariable Integer id) {
		entity.setIdMovieTags(id);
		return resource.toResource(tags_service.update(entity));
	}

}
