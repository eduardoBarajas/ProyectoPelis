package com.CODEns.BackendAPI.Entities;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class MovieCast {
    @Id
	@GeneratedValue(strategy = GenerationType.AUTO)
    private int IdCast;
    private int IdActor;
    private int IdMovie;

    public MovieCast(int IdCast, int IdActor, int IdMovie) {
        this.IdActor = IdActor;
        this.IdCast = IdCast;
        this.IdMovie = IdMovie;
    }

    public int getId() { return IdCast; }

	public void setIdCast(int IdCast) {
		this.IdCast = IdCast;
    }
    
    public int getIdActor() { return IdActor; }

	public void setIdActor(int IdActor) {
		this.IdActor = IdActor;
	}

	public int getIdMovie() {
		return IdMovie;
	}

	public void setIdMovie(int IdMovie) {
		this.IdMovie = IdMovie;
	}
	
	
	
}
