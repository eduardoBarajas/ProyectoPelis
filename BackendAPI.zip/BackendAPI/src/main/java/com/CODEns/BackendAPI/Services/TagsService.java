package com.CODEns.BackendAPI.Services;

import java.util.LinkedList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.CODEns.BackendAPI.DTOs.TagDTO;
import com.CODEns.BackendAPI.Entities.Tag;
import com.CODEns.BackendAPI.Interfaces.ServiceInterface;
import com.CODEns.BackendAPI.Repositories.TagRepository;

@Service
public class TagsService implements ServiceInterface<Tag, TagDTO> {

	@Autowired
	private TagRepository tagRepository;
	
	@Override
	public TagDTO save(Tag entity) {
		Tag new_tag = tagRepository.save(entity);
		TagDTO tag_dto;
		if (new_tag.getId() > 0) {
			tag_dto = new TagDTO(new_tag, "Success", "Se almaceno el tag con exito.");
		} else {
			tag_dto = new TagDTO("Error", "No se pudo guardar el tag en la base de datos.");
		}
		return tag_dto;
	}

	@Override
	public List<TagDTO> findAll() {
		List<TagDTO> tags_dto = new LinkedList<>();
		for(Tag tag : tagRepository.findAll()) {
			tags_dto.add(new TagDTO(tag));
		}
		return tags_dto;
	}

	@Override
	public TagDTO getById(Integer id) {
		TagDTO tag_dto = new TagDTO("Error", "No se encontro el tag en la base de datos.");
		if (tagRepository.existsById(id)) {
			Tag tag = tagRepository.findById(id).get();
			tag_dto = new TagDTO(tag, "Success", "Se obtuvo el tag con exito.");
		}
		return tag_dto;
	}

	@Override
	public TagDTO deleteById(Integer id) {
		TagDTO tag_dto = new TagDTO("Error", "No existe ese tag en la base de datos.");
		if (tagRepository.existsById(id)) {
			tagRepository.deleteById(id);
			tag_dto.setMessage("Se elimino ese tag con exito.");
			tag_dto.setStatus("Success");
		}
		return tag_dto;
	}

	@Override
	public TagDTO update(Tag entity) {
		TagDTO tag_dto = new TagDTO("Error", "No se encontro el tag en la base de datos.");
		if (tagRepository.existsById(entity.getId())) {
			tag_dto = new TagDTO(tagRepository.save(entity), "Success", "Se actualizo el tag con exito.");
		}
		return tag_dto;
	}

}
