package com.CODEns.BackendAPI.DTOs;

import com.CODEns.BackendAPI.Entities.MovieTags;

public class MovieTagDTO {
	private int IdMovieTags;
    private int IdTag;
    private int IdMovie;
    private String Status;
    private String Message;
    
	public MovieTagDTO(MovieTags mt, String Status, String Message) {
		this.IdMovie = mt.getIdMovie();
		this.IdTag = mt.getIdTag();
		this.IdMovieTags = mt.getIdMovieTags();
		this.Status = Status;
		this.Message = Message;
	}
	
	public MovieTagDTO(String Status, String Message) {
		this.Status = Status;
		this.Message = Message;
	}
	
	public MovieTagDTO(MovieTags mt) {
		this.IdMovie = mt.getIdMovie();
		this.IdTag = mt.getIdTag();
		this.IdMovieTags = mt.getIdMovieTags();
	}
	
	public int getIdMovieTags() {
		return IdMovieTags;
	}
	public void setIdMovieTags(int IdMovieTags) {
		this.IdMovieTags = IdMovieTags;
	}
	public int getIdTag() {
		return IdTag;
	}
	public void setIdTag(int IdTag) {
		this.IdTag = IdTag;
	}
	public int getIdMovie() {
		return IdMovie;
	}
	public void setIdMovie(int IdMovie) {
		this.IdMovie = IdMovie;
	}

	public String getStatus() {
		return Status;
	}

	public void setStatus(String Status) {
		this.Status = Status;
	}

	public String getMessage() {
		return Message;
	}

	public void setMessage(String Message) {
		this.Message = Message;
	}
	
}
