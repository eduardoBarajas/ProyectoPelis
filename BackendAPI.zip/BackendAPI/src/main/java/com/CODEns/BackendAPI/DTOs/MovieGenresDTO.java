package com.CODEns.BackendAPI.DTOs;

import com.CODEns.BackendAPI.Entities.MovieGenres;

public class MovieGenresDTO {
	private int IdGenres;
    private int IdGenre;
    private int IdMovie;
    private String Status;
    private String Message;

    public MovieGenresDTO(MovieGenres movieGenres, String status, String message) {
        this.IdGenres = movieGenres.getId();
        this.IdGenre = movieGenres.getIdGenre();
        this.IdMovie = movieGenres.getIdMovie();
        this.Status = status;
        this.Message = message;
    }
    
    public MovieGenresDTO(String status, String message) {
        this.Status = status;
        this.Message = message;
    }
    
    public MovieGenresDTO(MovieGenres movieGenres) {
        this.IdGenres = movieGenres.getId();
        this.IdGenre = movieGenres.getIdGenre();
        this.IdMovie = movieGenres.getIdMovie();
    }

    public int getIdGenre() { return IdGenre; }

	public void setIdGenre(int IdGenre) {
		this.IdGenre = IdGenre;
    }
    
    public int getId() { return IdGenres; }

	public void setIdGenres(int IdGenres) {
		this.IdGenres = IdGenres;
	}

	public int getIdMovie() {
		return IdMovie;
	}

	public void setIdMovie(int IdMovie) {
		this.IdMovie = IdMovie;
	}

	public String getStatus() {
		return Status;
	}

	public void setStatus(String status) {
		Status = status;
	}

	public String getMessage() {
		return Message;
	}

	public void setMessage(String message) {
		Message = message;
	}
	
}
