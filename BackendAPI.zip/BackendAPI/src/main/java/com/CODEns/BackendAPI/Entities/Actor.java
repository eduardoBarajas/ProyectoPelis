package com.CODEns.BackendAPI.Entities;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Actor {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
    private int IdActor;
    private String Name;

    public Actor(int id, String Name) {
        this.IdActor = id;
        this.Name = Name;
    }

    public String getName() { return Name; }

    public int getId() { return IdActor; }

	public void setIdActor(int IdActor) {
		this.IdActor = IdActor;
	}

	public void setName(String Name) {
		this.Name = Name;
	}
	
}