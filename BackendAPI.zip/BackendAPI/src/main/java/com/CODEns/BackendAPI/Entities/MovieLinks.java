package com.CODEns.BackendAPI.Entities;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class MovieLinks {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int IdMovieLinks;
    private int IdLinkVideo;
    private int IdMovie;

    public MovieLinks(int id, int id_link, int IdMovie) {
        this.IdMovieLinks = id;
        this.IdLinkVideo = id_link;
        this.IdMovie = IdMovie;
    }

	public int getIdMovieLinks() {
		return IdMovieLinks;
	}

	public void setIdMovieLinks(int IdMovieLinks) {
		this.IdMovieLinks = IdMovieLinks;
	}

	public int getIdLinkVideo() {
		return IdLinkVideo;
	}

	public void setIdLinkVideo(int IdLinkVideo) {
		this.IdLinkVideo = IdLinkVideo;
	}

	public int getIdMovie() {
		return IdMovie;
	}

	public void setIdMovie(int IdMovie) {
		this.IdMovie = IdMovie;
	}
    
    
}