package com.CODEns.BackendAPI.DTOs;

import com.CODEns.BackendAPI.Entities.Review;

public class ReviewDTO {
	private int IdReview;
    private double Calification;
    private String Review;
    private int IdUser;
    private String Status;
    private String Message;

    public ReviewDTO(Review review, String status, String message) {
        this.IdReview = review.getId_Review();
        this.Calification = review.getCalification();
        this.Review = review.getReview();
        this.IdUser = review.getIdUser();
        this.Status = status;
        this.Message = message;
    }
    
    public ReviewDTO(String status, String message) {
        this.Status = status;
        this.Message = message;
    }
    
    public ReviewDTO(Review review) {
        this.IdReview = review.getId_Review();
        this.Calification = review.getCalification();
        this.Review = review.getReview();
        this.IdUser = review.getIdUser();
    }
    
	public int getId_Review() {
		return IdReview;
	}

	public void setId_Review(int IdReview) {
		this.IdReview = IdReview;
	}

	public double getCalification() {
		return Calification;
	}

	public void setCalification(double Calification) {
		this.Calification = Calification;
	}

	public String getReview() {
		return Review;
	}

	public void setReview(String Review) {
		this.Review = Review;
	}

	public int getIdUser() {
		return IdUser;
	}

	public void setIdUser(int IdUser) {
		this.IdUser = IdUser;
	}

	public String getStatus() {
		return Status;
	}

	public void setStatus(String status) {
		Status = status;
	}

	public String getMessage() {
		return Message;
	}

	public void setMessage(String message) {
		Message = message;
	}
	
	
}
