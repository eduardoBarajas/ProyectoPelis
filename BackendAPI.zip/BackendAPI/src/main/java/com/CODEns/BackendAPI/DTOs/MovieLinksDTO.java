package com.CODEns.BackendAPI.DTOs;

import com.CODEns.BackendAPI.Entities.MovieLinks;

public class MovieLinksDTO {
	private int IdMovieLinks;
    private int IdLinkVideo;
    private int IdMovie;
    private String Status;
    private String Message;

    public MovieLinksDTO(MovieLinks movieLinks, String status, String message) {
        this.IdMovieLinks = movieLinks.getIdMovieLinks();
        this.IdLinkVideo = movieLinks.getIdLinkVideo();
        this.IdMovie = movieLinks.getIdMovie();
        this.Status = status;
        this.Message = message;
    }
    
    public MovieLinksDTO(String status, String message) {
        this.Status = status;
        this.Message = message;
    }
    
    public MovieLinksDTO(MovieLinks movieLinks) {
        this.IdMovieLinks = movieLinks.getIdMovieLinks();
        this.IdLinkVideo = movieLinks.getIdLinkVideo();
        this.IdMovie = movieLinks.getIdMovie();
    }

	public int getIdMovieLinks() {
		return IdMovieLinks;
	}

	public void setIdMovieLinks(int IdMovieLinks) {
		this.IdMovieLinks = IdMovieLinks;
	}

	public int getIdLinkVideo() {
		return IdLinkVideo;
	}

	public void setIdLinkVideo(int IdLinkVideo) {
		this.IdLinkVideo = IdLinkVideo;
	}

	public int getIdMovie() {
		return IdMovie;
	}

	public void setIdMovie(int IdMovie) {
		this.IdMovie = IdMovie;
	}

	public String getStatus() {
		return Status;
	}

	public void setStatus(String status) {
		Status = status;
	}

	public String getMessage() {
		return Message;
	}

	public void setMessage(String message) {
		Message = message;
	}
	
}
