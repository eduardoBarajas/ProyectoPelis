package com.CODEns.BackendAPI.Repositories;

import org.springframework.data.repository.CrudRepository;

import com.CODEns.BackendAPI.Entities.WatchLaterMovie;

public interface WatchLaterMovieRepository extends CrudRepository<WatchLaterMovie, Integer>{

}
