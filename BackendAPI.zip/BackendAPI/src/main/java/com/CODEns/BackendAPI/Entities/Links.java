package com.CODEns.BackendAPI.Entities;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Links {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
    private int IdLinkVideo;
    private String Link;

    public Links(int id, String Link) {
        IdLinkVideo = id;
        this.Link = Link;
    }

	public int getIdLinkVideo() {
		return IdLinkVideo;
	}

	public void setIdLinkVideo(int IdLinkVideo) {
		this.IdLinkVideo = IdLinkVideo;
	}

	public String getLink() {
		return Link;
	}

	public void setLink(String Link) {
		this.Link = Link;
	}

    
}